
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.7.1'
version = '1.7.1'
full_version = '1.7.1'
git_revision = '47bb6fe'
commit_count = '1245'
release = True

if not release:
    version = full_version
